import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

public class WordUtilTest {

    @Test
    public  void wordUtilTestDeletion() {
        Set<String> resultSet1 = new HashSet<>(Arrays.asList("ak", "aa","ka"));
        assertEquals(resultSet1, WordUtil.createDeletionList("aka"));

        Set<String> resultSet2 =  new HashSet<>(Arrays.asList("0ab", "a b","0 b", "0a "));
        assertEquals(resultSet2, WordUtil.createDeletionList("0a b"));
    }

    @Test
    public void wordUtilInsertion() {
        Set<String> resultSet1= new HashSet<>();
        for(char c: WordUtil.getLetters()) {
            resultSet1.add(new String(String.valueOf(c)));
        }
        assertEquals(resultSet1, WordUtil.createInsertionList(""));
    }

    @Test
    public void wordUtilReplacement() {
        Set<String> resultSet1= new HashSet<>();
        for(char c: WordUtil.getLetters()) {
            resultSet1.add(new String(String.valueOf(c)));
        }
        resultSet1.remove("a");
        assertEquals(resultSet1, WordUtil.createReplacementSet("a"));
    }

    @Test
    public void findMatchingwords() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method findMatchingWords = WordChainBuilder.class.getDeclaredMethod("findMatchingWords", List.class, Set.class, String.class );
        findMatchingWords.setAccessible(true);

        Method getAllPattern = WordChainBuilder.class.getDeclaredMethod("createAllPattern", String.class);
        getAllPattern.setAccessible(true);

        WordChainBuilder builder = new WordChainBuilder();

        Set<String> resultSet1 = new HashSet<>(Arrays.asList("aka","k","bk"));
        List<String> parameterList = new ArrayList<>(Arrays.asList("aka", "k", "bk", "ka", "xx", "a k", "ak"));

        assertEquals(resultSet1, findMatchingWords.invoke(builder, parameterList, getAllPattern.invoke(builder,"ak"), "ak"));
    }
}
