import java.util.*;

public class WordChainBuilder {
    private List<String> words;



    public List<String> getWords() {
        return words;
    }

    /**
     *
     * @param parameterList a még be nem illesztett szavak listája
     * @param matchingWords azon kandidáns szavak szetje, amik beilleszthetők az előző szóhóz
     * @return rekurzivan feltöltött lista a megtalált szavakkal, vagy null ha ez nem lehetséges
     */
    public List<String> buildChain(List<String> parameterList, Set<String> matchingWords ) {

        if(parameterList.size() == 1) {
            return new ArrayList<String>(Arrays.asList(parameterList.get(0)));
        }
        for(String currentWord: matchingWords) {
            Set<String> allPattern = createAllPattern(currentWord);
            Set<String> newMatchingWords = findMatchingWords(parameterList, allPattern, currentWord);


            if(newMatchingWords == null || newMatchingWords.isEmpty()) {
                continue;
            }

            List<String> newParameterList = createNewParameterList(parameterList,currentWord );
            List<String> response = buildChain(newParameterList, newMatchingWords);
            if(response !=null) {
                response.add(currentWord);
                return response;
            }
        }
        return null;
    }




    private Set<String> createAllPattern(String currentWord) {
        Set<String> allPattern = new HashSet<>();

        allPattern.addAll(WordUtil.createDeletionList(currentWord));
        allPattern.addAll(WordUtil.createInsertionList(currentWord));
        allPattern.addAll(WordUtil.createReplacementSet(currentWord));

        return allPattern;
    }

    private Set<String> findMatchingWords(List<String> parameterList, Set<String> allPattern, String curerntParameter) {
        Set<String> matchingWords = new HashSet<>();

        for(String currentWord: parameterList) {
            for(String currentPattern: allPattern) {
                if(currentWord.equalsIgnoreCase(currentPattern) && !currentWord.equalsIgnoreCase(curerntParameter)) {
                    matchingWords.add(currentWord);
                }
            }
        }

        return matchingWords;
    }

    private List<String> createNewParameterList(List<String> parameterList, String currentWord) {
        List<String> newParameterList = new ArrayList<>();
        for(String s: parameterList) {
            if(!s.equalsIgnoreCase(currentWord)) {
                newParameterList.add(s);
            }
        }

        return newParameterList;
    }
}
