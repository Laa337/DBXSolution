import java.util.HashSet;
import java.util.Set;

/**
 *  Ez az osztály tartalmazza azokat a statikus függvényeket,
 *  amik a delécios, inzerciós és hellyetesítős mintákat kreálják
 */
public class WordUtil {
    /**
     *  statikus karaktetomb az angol abc betuivel + 1 es 0 is szerepel benne
     */
    private static char[] letters = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
                                        'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' , '0', '1'};


    public static char[] getLetters() {
        return letters;
    }

    public static Set<String> createDeletionList(String word) {
        Set<String> deletions = new HashSet<>();
        StringBuilder baseWord = new StringBuilder(word);

        for(int i=0; i<word.length(); i++) {
            deletions.add(new StringBuilder(baseWord).deleteCharAt(i).toString());
        }

        return deletions;
    }
    
    public static Set<String> createInsertionList(String word) {
        Set<String> insertions = new HashSet<>();
        StringBuilder baseWord = new StringBuilder(word);

        for(int i=0; i<=word.length(); i++) {
            for(int j=0; j<letters.length; j++) {
                insertions.add(new StringBuilder(baseWord).insert(i, letters[j]).toString() );
            }
        }
        
        return insertions;
    }

    public static Set<String> createReplacementSet(String word) {
        Set<String> replacements = new HashSet<>();
        StringBuilder baseWord = new StringBuilder(word);

        for(int i=0; i<word.length(); i++) {
            for(int j=0; j<letters.length; j++) {
                if(letters[j] != baseWord.charAt(i)) {
                    StringBuilder currentReplacement = new StringBuilder(baseWord);
                    currentReplacement.setCharAt(i, letters[j]);
                    replacements.add(currentReplacement.toString());
                }
            }
        }

        return replacements;
    }
}
