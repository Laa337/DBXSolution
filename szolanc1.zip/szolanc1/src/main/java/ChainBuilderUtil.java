import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class ChainBuilderUtil {

    public void buildChainFromArgs(String[] args) {
        String valid = validateArgs(args);
        if (!valid.equals("")) {
            System.out.println("Hiba a bemeneti parameterekkel:  " + valid);
            return;
        }

        List<String> parameterList = new ArrayList<>(Arrays.asList(args));
        WordChainBuilder wordChainBuilder = new WordChainBuilder();
        Set<String> matchingWords = new HashSet<>(parameterList);
        List<String> wordChain = wordChainBuilder.buildChain(parameterList, matchingWords);

        if (wordChain != null) {
            System.out.println("\n\nSzólánc kirakása sikeres paraméterekből\n");
            wordChain.forEach(System.out::println);
        } else {
            System.out.println("hiba: a megadott szavakból nem lehetséges szóláncot építeni!");
        }
    }


    public void buildChainFromFile(String file) {
        List<String> words;
        try {
            words =  Files.lines(Paths.get(System.getProperty("user.dir") + "\\" + file), StandardCharsets.UTF_8).collect(Collectors.toList());
            String valid = validateArgs(words.toArray(new String[0]));
            if( !valid.equals("") ) {
                System.out.println("Hiba a bemeneti parameterekkel:  " + valid);
                return;
            }


            WordChainBuilder wordChainBuilder = new WordChainBuilder();
            Set<String> matchingWords = new HashSet<>(words);
            List<String> wordChain = wordChainBuilder.buildChain(words, matchingWords);

            if(wordChain !=null) {
                System.out.println("\n\nSzólánc kirakása sikeres fájlból\n");
                wordChain.forEach(System.out::println);
            }
            else {
                System.out.println("hiba: a megadott szavakból nem lehetséges szóláncot építeni!");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String validateArgs(String[] args) {
        String valid = "";
        if (args == null || args.length == 0) {
            valid += "Hiányzo bemeneti parameterek";
        } else if (args.length > 20) {
            valid += "Túl sok parameter";
        }
        return valid;
    }


}
