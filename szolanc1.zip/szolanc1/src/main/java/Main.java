public class Main {

    public static void main(String[] args) {
        ChainBuilderUtil chainBuilderUtil = new ChainBuilderUtil();
        chainBuilderUtil.buildChainFromArgs(args);
        chainBuilderUtil.buildChainFromFile("szavak.txt");
    }
}
